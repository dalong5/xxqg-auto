import * as plain from './src/xxqg/plain.js';
const r = await plain.rects();
console.log('tip', JSON.stringify(r.tip));
await plain.clickAt(r.tip[0], r.tip[1]);
await new Promise((x) => setTimeout(x, 1500));
console.log((await plain.probe("(function(){var a=[].filter.call(document.querySelectorAll('*'),function(e){return e.children.length===0&&e.innerText&&e.innerText.indexOf('答案')>=0});document.title='D:'+a.map(function(e){return e.className+'|'+e.innerText.slice(0,20)}).join(' ;; ').slice(0,260)})()")).slice(0, 280));