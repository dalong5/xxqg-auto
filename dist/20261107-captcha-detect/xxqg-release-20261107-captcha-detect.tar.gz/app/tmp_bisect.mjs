import * as plain from './src/xxqg/plain.js';
const alive = async (tag) => {
  const t = await plain.title().catch((e) => 'DEAD:' + e.message.slice(0, 20));
  console.log(tag, String(t).slice(0, 40));
  return !String(t).startsWith('DEAD');
};
const r = await plain.rects();
console.log('opts', r.opts.length, 'btns', r.btns.map((b) => b.t).join(','));
await alive('before option');
await plain.clickAt(r.opts[0].c[0], r.opts[0].c[1]);
await new Promise((x) => setTimeout(x, 900));
await alive('after option');
const tip = await plain.tipRect();
console.log('tip', JSON.stringify(tip));
if (tip) {
  await plain.clickAt(tip[0], tip[1]);
  await new Promise((x) => setTimeout(x, 1200));
  await alive('after tip');
  console.log('hint', (await plain.hintText()).slice(0, 40));
}
const r2 = await plain.rects();
const fin = r2.btns.find((b) => /确/.test(b.t));
console.log('fin', JSON.stringify(fin));
await plain.clickAt(fin.c[0], fin.c[1]);
await new Promise((x) => setTimeout(x, 2000));
await alive('after confirm');