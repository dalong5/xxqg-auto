import * as plain from './src/xxqg/plain.js';
const t = await plain.tipRect();
console.log('tipRect', JSON.stringify(t));
const raw = await plain.probe(plain.TIP_JS);
console.log('raw', raw.slice(0, 60));