import * as plain from './src/xxqg/plain.js';
import { Jar, score } from './src/xxqg/client.js';
import { DatabaseSync } from 'node:sqlite';
import { open as unseal } from './src/crypto.js';
const uid = '151285958047.0';
const d = new DatabaseSync('data/app.db');
const jar = new Jar(unseal(d.prepare('select sealed_cookie from users where uid=?').get(uid).sealed_cookie));
const log = (...a) => console.log(new Date().toISOString().slice(11, 19), ...a);
await plain.seedProfile(uid, jar);
await plain.open(uid, 'https://pc.xuexi.cn/points/exam-practice.html');
log('opened');
for (let q = 1; q <= 8; q++) {
  const r0 = await plain.rects();
  const b0 = (r0.btns || []).map((b) => b.t.replace(/\s/g, ''));
  log(`q${q} opts=${(r0.opts || []).length} blanks=${(r0.blanks || []).length} btns=${b0.join('/')}`);
  if (b0.some((x) => x.includes('完成'))) break;
  const out = await plain.advance();
  log(`   ${out.decided} hint=${JSON.stringify((out.hint || '').slice(0, 30))}`);
  await new Promise((x) => setTimeout(x, 1200));
}
const r = await plain.rects();
const fin = (r.btns || []).find((b) => /完成/.test(b.t));
log('final btns=' + (r.btns || []).map((b) => b.t).join('/'));
if (fin) {
  await plain.clickAt(fin.c[0], fin.c[1]);
  await new Promise((x) => setTimeout(x, 2500));
  const s = await plain.rects();
  log('slider=' + JSON.stringify(s.slider) + ' track=' + JSON.stringify(s.track));
  if (s.slider && s.track) {
    await plain.drag(s.slider[0], s.slider[1], s.track[0], s.track[1], 34);
    await new Promise((x) => setTimeout(x, 4000));
  }
}
const after = await score(jar);
log('RESULT 每日答题=' + JSON.stringify(after.tasks?.[6]) + ' 总分=' + after.total);