import { db } from './src/db.js';
const j = db.prepare('select id,status,error from jobs order by created_at desc limit 1').get();
const ev = db.prepare('select type,payload,created_at from events where job_id=? order by seq').all(j.id);
for (const e of ev) {
  let p = e.payload;
  try { p = JSON.stringify(JSON.parse(p)); } catch {}
  console.log(new Date(Number(e.created_at)).toISOString().slice(11, 19), e.type, String(p).slice(0, 110));
}
console.log('STATUS', j.status, j.error || '');