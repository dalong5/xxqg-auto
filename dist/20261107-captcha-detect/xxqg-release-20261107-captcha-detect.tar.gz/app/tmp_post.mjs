import crypto from 'node:crypto';
import fs from 'node:fs';
import { DatabaseSync } from 'node:sqlite';
const key = Buffer.from(fs.readFileSync('data/secret.key', 'utf8').trim(), 'hex');
const uid = '151285666237.0';
const d = new DatabaseSync('data/app.db');
const v = d.prepare('select visitor_id from users where uid=?').get(uid).visitor_id;
const sig = crypto.createHmac('sha256', key).update(v).digest('base64url').slice(0, 22);
const cookie = `xxqg_v=${encodeURIComponent(v + '.' + sig)}`;
const tasks = (process.argv[2] || 'daily').split(',');
const r = await fetch(`http://127.0.0.1:8099/api/users/${uid}/run`, {
  method: 'POST', headers: { cookie, 'content-type': 'application/json' }, body: JSON.stringify({ tasks }),
});
console.log(r.status, await r.text());