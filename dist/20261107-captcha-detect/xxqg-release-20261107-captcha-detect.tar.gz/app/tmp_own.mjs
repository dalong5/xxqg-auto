import { db } from './src/db.js';
console.log(JSON.stringify(db.prepare("select name from pragma_table_info('users')").all().map((r) => r.name)));
console.log(JSON.stringify(db.prepare('select uid, visitor_id, nick from users').all()));