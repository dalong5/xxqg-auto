import fs from 'node:fs';
import crypto from 'node:crypto';
import { DatabaseSync } from 'node:sqlite';
const key = Buffer.from(fs.readFileSync('data/ck.key', 'utf8').trim(), 'base64');
const d = new DatabaseSync('data/ck_snapshot.db');
const row = d.prepare("select encrypted_value from cookies where name='__UID__'").get();
const raw = row.encrypted_value;
console.log('prefix', raw.subarray(0, 3).toString(), 'len', raw.length);
try {
  const dc = crypto.createDecipheriv('aes-256-gcm', key, raw.subarray(3, 15));
  dc.setAuthTag(raw.subarray(raw.length - 16));
  console.log('OK', Buffer.concat([dc.update(raw.subarray(15, raw.length - 16)), dc.final()]).toString().slice(0, 40));
} catch (e) { console.log('FAIL', e.message.slice(0, 40)); }