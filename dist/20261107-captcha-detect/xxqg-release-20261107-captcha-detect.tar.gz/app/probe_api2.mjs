import { DatabaseSync } from 'node:sqlite';
const d = new DatabaseSync('data/app.db');
const jar = JSON.parse(d.prepare("select jar from logins where status='done' order by created_at desc limit 1").get().jar);
const ck = Object.entries(jar).map(([k, v]) => `${k}=${v}`).join('; ');
const H = { cookie: ck, 'content-type': 'application/json', referer: 'https://pc.xuexi.cn/points/exam-practice.html', 'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36' };
for (const u of ['https://pc.xuexi.cn/api/exam/detectRisk', 'https://pc.xuexi.cn/api/exam/service/practice/quizSubmitV3', 'https://pc.xuexi.cn/api/exam/service/practice/quizSubmit']) {
  const r = await fetch(u, { method: u.endsWith('detectRisk') ? 'GET' : 'POST', headers: H, body: u.endsWith('detectRisk') ? undefined : '{}' });
  console.log(u.split('/').slice(-2).join('/'), r.status, (await r.text()).slice(0, 200));
}