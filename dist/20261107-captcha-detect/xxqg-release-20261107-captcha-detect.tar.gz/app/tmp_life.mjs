import * as plain from './src/xxqg/plain.js';
import { Jar } from './src/xxqg/client.js';
import { DatabaseSync } from 'node:sqlite';
import { open as unseal } from './src/crypto.js';
const uid = '151285958047.0';
const d = new DatabaseSync('data/app.db');
const jar = new Jar(unseal(d.prepare('select sealed_cookie from users where uid=?').get(uid).sealed_cookie));
await plain.seedProfile(uid, jar);
console.log('seeded');
await plain.open(uid, 'https://pc.xuexi.cn/points/exam-practice.html');
for (let i = 0; i < 6; i++) {
  const t = await plain.title().catch((e) => 'ERR ' + e.message.slice(0, 30));
  console.log(i, String(t).slice(0, 50));
  await new Promise((r) => setTimeout(r, 4000));
}