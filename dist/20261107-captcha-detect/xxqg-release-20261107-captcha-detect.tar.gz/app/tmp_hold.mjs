// 诊断：按住并移动到一半，截图看手柄是否真的动了；再释放
import fs from 'node:fs';
import { db } from './src/db.js';

const job = db.prepare("select id from jobs where status = 'running' order by rowid desc limit 1").get();
if (!job) { console.log('no job'); process.exit(0); }
const lastFrame = () => {
  const f = db.prepare("select type, payload, created_at from events where job_id = ? order by seq desc limit 1").get(job.id);
  return f;
};
const f0 = lastFrame();
if (f0?.type !== 'verification') { console.log('no pending verification:', f0?.type); process.exit(0); }
const { width, height } = JSON.parse(f0.payload);

const startX = Math.round(width * 0.395);
const y = Math.round(height * 0.5645);
const midX = Math.round(width * 0.52);
const ins = db.prepare('INSERT INTO verification_actions (job_id, kind, x, y) VALUES (?,?,?,?)');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
db.prepare('DELETE FROM verification_actions WHERE job_id = ?').run(job.id);

ins.run(job.id, 'move', startX, y);
await sleep(100);
ins.run(job.id, 'down', startX, y);
await sleep(150);
for (let i = 1; i <= 6; i++) {
  ins.run(job.id, 'move', Math.round(startX + (midX - startX) * (i / 6)), y);
  await sleep(70);
}
console.log('已按住并移动到', midX, '，等待新帧…');

// 等一帧新的（holding 状态）
let shot = null;
for (let i = 0; i < 20; i++) {
  await sleep(300);
  const f = lastFrame();
  if (f && f.seq !== f0.seq && f.type === 'verification') { shot = f; break; }
}
if (shot) {
  const obj = JSON.parse(shot.payload);
  fs.writeFileSync('../logs/holding.jpg', Buffer.from(String(obj.image || obj), 'base64'));
  console.log('holding 帧已保存', obj.width + 'x' + obj.height);
}
console.log('本次帧 seq:', shot?.seq || '无新帧', '起始 seq:', f0.seq);
