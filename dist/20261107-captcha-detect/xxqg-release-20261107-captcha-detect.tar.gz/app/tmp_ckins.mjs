import fs from 'node:fs';
import { DatabaseSync } from 'node:sqlite';
const db = new DatabaseSync(process.argv[2]);
const rows = JSON.parse(fs.readFileSync('data/ck.rows.json', 'utf8'));
const now = BigInt(Date.now()) * 1000n + 11644473600000000n;
const exp = now + 86400n * 30n * 1000000n;
const ins = db.prepare(`INSERT INTO cookies (creation_utc, host_key, top_frame_site_key, name, value, encrypted_value, path, expires_utc, is_secure, is_httponly, last_access_utc, has_expires, is_persistent, priority, samesite, source_scheme, source_port, last_update_utc, source_type, has_cross_site_ancestor) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`);
for (const r of rows) {
  ins.run(now, '.xuexi.cn', '', r.name, '', Buffer.from(r.blob, 'base64'), '/', exp, 1, 1, now, 1, 1, 1, -1, 2, 443, now, 0, 0);
}
console.log('inserted', rows.length, JSON.stringify(db.prepare('select name, host_key from cookies').all()));