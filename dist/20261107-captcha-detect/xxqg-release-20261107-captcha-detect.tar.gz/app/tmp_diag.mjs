import { DatabaseSync } from 'node:sqlite';
import { open as unseal } from './src/crypto.js';
const d = new DatabaseSync('data/app.db');
for (const r of d.prepare('select uid, sealed_cookie from users').all()) {
  const v = r.sealed_cookie;
  let out = 'fail';
  try { out = 'ok:' + Object.keys(unseal(v)).join(','); } catch (e) { out = 'fail:' + e.message.slice(0, 30); }
  console.log(r.uid, typeof v, v?.length ?? v?.byteLength, out);
}