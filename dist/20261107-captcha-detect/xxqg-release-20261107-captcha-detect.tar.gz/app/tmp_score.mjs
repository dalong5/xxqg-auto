import { Jar, score } from './src/xxqg/client.js';
import { DatabaseSync } from 'node:sqlite';
import { open as unseal } from './src/crypto.js';
const d = new DatabaseSync('data/app.db');
const jar = new Jar(unseal(d.prepare('select sealed_cookie from users where uid=?').get('151285666237.0').sealed_cookie));
const s = await score(jar);
console.log(JSON.stringify(s).slice(0, 400));