import { DatabaseSync } from 'node:sqlite';
const d = new DatabaseSync('data/app.db');
const id = 'dc9c7c46-ad5f-426d-964a-6c647f01482c';
for (let i = 0; i < 60; i++) {
  const j = d.prepare('select status from jobs where id = ?').get(id);
  if (['done', 'failed'].includes(j.status)) {
    console.log('STATUS', j.status);
    for (const e of d.prepare("select type, payload from events where job_id = ? and type in ('log','bad','ok') order by seq desc limit 5").all(id)) {
      console.log(e.type, '|', (e.payload || '').slice(0, 90));
    }
    break;
  }
  await new Promise((r) => setTimeout(r, 4000));
}