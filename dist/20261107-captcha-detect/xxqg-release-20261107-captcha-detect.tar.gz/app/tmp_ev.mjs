import { db } from './src/db.js';
const j = db.prepare('select id,status,error from jobs order by created_at desc limit 1').get();
console.log('job', JSON.stringify(j));
const ev = db.prepare('select ts,level,message from events where job_id=? order by ts desc limit 12').all(j.id);
for (const e of ev.reverse()) console.log(new Date(Number(e.ts)).toISOString().slice(11, 19), e.message);