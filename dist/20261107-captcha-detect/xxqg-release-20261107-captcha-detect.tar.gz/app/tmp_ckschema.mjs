import { DatabaseSync } from 'node:sqlite';
const db = new DatabaseSync(process.argv[2]);
console.log(db.prepare("select sql from sqlite_master where name='cookies'").get().sql.replace(/\s+/g,' '));