// 在人工验证通道上代替用户完成「拖动到最右边」：直接写 verification_actions 表
import { db } from './src/db.js';

const job = db.prepare("select id, status from jobs where status = 'running' order by rowid desc limit 1").get();
if (!job) {
  console.log('没有 running 任务');
  process.exit(0);
}
const frame = db
  .prepare("select type, payload from events where job_id = ? and type in ('verification','verification-end') order by seq desc limit 1")
  .get(job.id);
if (!frame || frame.type !== 'verification') {
  console.log('当前没有待处理验证，最近帧类型 =', frame?.type);
  process.exit(0);
}
const { width, height } = JSON.parse(frame.payload);
console.log('job', job.id.slice(0, 8), 'viewport', width + 'x' + height);

// 从截图估出的滑块几何：手柄在左端，轨道右端约 930
const startX = Math.round(width * 0.385);
const startY = Math.round(height * 0.565);
const endX = Math.round(width * 0.606);
console.log('drag', startX, startY, '->', endX, startY);

const ins = db.prepare('INSERT INTO verification_actions (job_id, kind, x, y) VALUES (?,?,?,?)');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

db.prepare('DELETE FROM verification_actions WHERE job_id = ?').run(job.id);
ins.run(job.id, 'move', startX, startY);
await sleep(60);
ins.run(job.id, 'down', startX, startY);
await sleep(120);

const steps = 14;
for (let i = 1; i <= steps; i++) {
  const t = i / steps;
  const eased = 1 - Math.pow(1 - t, 3);
  const x = Math.round(startX + (endX - startX) * eased);
  ins.run(job.id, 'move', x, startY);
  await sleep(45 + Math.random() * 35);
}
ins.run(job.id, 'move', endX, startY);
await sleep(120);
ins.run(job.id, 'up', endX, startY);
console.log('动作已写入，等待 worker 转发');

await sleep(2500);
const after = db.prepare('select type from events where job_id = ? order by seq desc limit 1').get(job.id);
const j2 = db.prepare('select status, error from jobs where id = ?').get(job.id);
const pending = db.prepare('select count(*) n from verification_actions where job_id = ?').get(job.id).n;
console.log('最新帧类型:', after?.type, '| 待转发动作:', pending, '| 任务:', j2.status, j2.error || '');
