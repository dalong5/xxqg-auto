import { enqueue, db } from './src/db.js';
const uid = '151285666237.0';
db.prepare('update jobs set status=?, finished_at=? where status in (?,?)').run('cancelled', Date.now(), 'queued', 'running');
const id = enqueue({ kind: 'run', uid, visitorId: 'manual', tasks: ['daily'] });
console.log('job', id, 'queued', db.queuedCount());