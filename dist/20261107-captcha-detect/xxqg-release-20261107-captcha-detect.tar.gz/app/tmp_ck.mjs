import { Jar, userInfo, score } from './src/xxqg/client.js';
import { DatabaseSync } from 'node:sqlite';
import { open as unseal } from './src/crypto.js';
const d = new DatabaseSync('data/app.db');
const raw = unseal(d.prepare('select sealed_cookie from users where uid=?').get('151285666237.0').sealed_cookie);
const jar = new Jar(raw);
console.log('names', Object.keys(raw).join(','));
try { console.log('info', JSON.stringify(await userInfo(jar)).slice(0, 200)); } catch (e) { console.log('info err', e.message); }
try { console.log('score', JSON.stringify(await score(jar)).slice(0, 160)); } catch (e) { console.log('score err', e.message); }