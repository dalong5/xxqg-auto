import * as plain from './src/xxqg/plain.js';
const pg = async () => {
  const t = await plain.probe("(function(){var b=[].map.call(document.querySelectorAll('.q-answer'),function(e){return (e.className.indexOf('chosen')>=0?'*':'')+e.innerText.trim().slice(0,5)}).join('|');var p=(document.body.innerText.match(/(\\d)\\/5/)||[])[0];document.title='S '+p+' :: '+b})()");
  return t.replace(' - Google Chrome', '');
};
console.log('before', await pg());
for (let i = 0; i < 3; i++) {
  await plain.advance();
  await new Promise((x) => setTimeout(x, 1200));
  console.log('step', i + 1, await pg());
}