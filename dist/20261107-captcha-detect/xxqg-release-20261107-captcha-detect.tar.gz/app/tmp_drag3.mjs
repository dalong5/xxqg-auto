import { db } from './src/db.js';

const job = db.prepare("select id from jobs where status = 'running' order by rowid desc limit 1").get();
if (!job) { console.log('no job'); process.exit(0); }
const f = db.prepare("select seq, type, payload from events where job_id = ? order by seq desc limit 1").get(job.id);
if (f?.type !== 'verification') { console.log('no pending verification:', f?.type); process.exit(0); }
const { width, height } = JSON.parse(f.payload);

const startX = Math.round(width * 0.396);
const y = Math.round(height * 0.565);
const endX = Math.round(width * 0.623);
console.log('fine drag', startX, y, '->', endX, y);

const ins = db.prepare('INSERT INTO verification_actions (job_id, kind, x, y) VALUES (?,?,?,?)');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
db.prepare('DELETE FROM verification_actions WHERE job_id = ?').run(job.id);

ins.run(job.id, 'move', startX - 3, y - 2);
await sleep(120);
ins.run(job.id, 'down', startX, y);
await sleep(200);
const steps = 40;
for (let i = 1; i <= steps; i++) {
  const t = i / steps;
  const eased = t < 0.15 ? t * 1.2 : 1 - Math.pow(1 - t, 1.8);
  ins.run(job.id, 'move', Math.round(startX + (endX - startX) * Math.min(1, eased)), y + (Math.random() - 0.5));
  await sleep(70);
}
ins.run(job.id, 'move', endX, y);
await sleep(220);
ins.run(job.id, 'up', endX, y);
console.log('sent', steps + 2, 'actions');

await sleep(3500);
const last = db.prepare('select type from events where job_id = ? order by seq desc limit 1').get(job.id);
const j = db.prepare('select status, error from jobs where id = ?').get(job.id);
console.log('last:', last?.type, '| job:', j.status, j.error || '');
