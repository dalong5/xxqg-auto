import * as plain from './src/xxqg/plain.js';
const r = await plain.rects();
console.log('tip?', !!r.tip, 'opts', (r.opts||[]).length, 'btns', (r.btns||[]).map(b=>b.t).join(','));
const c = r.opts[0].c;
await plain.clickAt(c[0], c[1]);
await new Promise((x) => setTimeout(x, 900));
console.log(await plain.probe("(function(){document.title='CLS:'+[].map.call(document.querySelectorAll('.q-answer'),function(e){return e.className}).join('|')})()"));