import * as plain from './src/xxqg/plain.js';
for (let i = 1; i <= 6; i++) {
  const r = await plain.advance();
  const fin = (r.btns || []).map((b) => b.t).join(',');
  console.log(i, 'btns=', fin, 'opts=', (r.opts || []).length, 'inputs=', (r.inputs || []).length);
  if (fin.includes('完')) break;
}