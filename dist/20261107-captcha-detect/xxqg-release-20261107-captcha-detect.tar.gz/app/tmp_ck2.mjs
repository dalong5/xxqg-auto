import fs from 'node:fs';
import { DatabaseSync } from 'node:sqlite';
import { open } from './src/crypto.js';
const d = new DatabaseSync('data/app.db');
const jar = open(d.prepare('select sealed_cookie from users where uid=?').get('151285666237.0').sealed_cookie);
fs.writeFileSync('data/ck.json', JSON.stringify(jar));
console.log(JSON.stringify(Object.keys(jar)));