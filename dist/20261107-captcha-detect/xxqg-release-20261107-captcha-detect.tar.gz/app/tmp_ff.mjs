import { firefox } from 'playwright';
try {
  const b = await firefox.launch({ headless: false });
  const p = await b.newPage();
  await p.goto('https://pc.xuexi.cn/points/exam-practice.html', { waitUntil: 'domcontentloaded' });
  await p.waitForTimeout(1500);
  console.log('ff ok', (await p.title()).slice(0, 40));
  await b.close();
} catch (e) {
  console.log('ff fail', String(e).slice(0, 200));
}