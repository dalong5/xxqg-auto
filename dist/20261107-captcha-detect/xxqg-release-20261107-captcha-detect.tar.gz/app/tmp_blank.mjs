import * as plain from './src/xxqg/plain.js';
const r = await plain.rects();
console.log('blanks', (r.blanks||[]).length, 'tiles', (r.tiles||[]).map(t=>t.t).join('/'));
await plain.advance();
await new Promise((x) => setTimeout(x, 1200));
console.log('after', (await plain.probe("document.title='P:'+document.body.innerText.slice(0,40)")).slice(0,60));