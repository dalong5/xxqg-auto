import * as plain from './src/xxqg/plain.js';
const st = async (tag) => {
  const t = await plain.probe("(function(){var b=[].map.call(document.querySelectorAll('.q-answer'),function(e){return (e.className.indexOf('chosen')>=0?'*':'-')+e.innerText.trim().slice(0,3)}).join('|');var btn=document.querySelector('.action-row button:last-child');var p=(document.body.innerText.match(/(\\d)\\/5/)||[])[0];document.title='S '+p+' ['+((btn||{}).innerText||'').trim().replace(/\\s/g,'')+'] '+b})()");
  console.log(tag, t.replace(' - Google Chrome', '').slice(0, 100));
};
await st('start ');
process.env.XXQG_DEBUG = '1';
const out = await plain.advance();
console.log('hint=', (out.hint || '').slice(0, 40), 'decided=', out.decided);
await new Promise((x) => setTimeout(x, 1500));
await st('after ');