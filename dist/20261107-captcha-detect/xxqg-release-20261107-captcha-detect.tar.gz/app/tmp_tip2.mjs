import * as plain from './src/xxqg/plain.js';
const r = await plain.rects();
await plain.clickAt(r.tip[0], r.tip[1]);
await new Promise((x) => setTimeout(x, 1200));
const t = await plain.probe("(function(){document.title='T:'+document.body.innerText.replace(/\\s+/g,' ').slice(0,260)})()");
console.log(t.slice(0, 280));
console.log('ant', (await plain.probe("(function(){var a=document.querySelectorAll('.ant-popover');document.title='A:'+a.length+'|'+(a[0]?a[0].className+'|'+a[0].innerText.replace(/\\s+/g,' ').slice(0,60):'')})()")).slice(0, 140));