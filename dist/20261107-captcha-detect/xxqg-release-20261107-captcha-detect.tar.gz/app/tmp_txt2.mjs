import * as plain from './src/xxqg/plain.js';
const JS = "(function(){document.title='B:'+document.body.innerText.replace(/\\s+/g,' ').slice(0,380)})()";
console.log(await plain.probe(JS));