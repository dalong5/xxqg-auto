import { DatabaseSync } from 'node:sqlite';
const d = new DatabaseSync('data/ck_snapshot.db');
console.log(JSON.stringify(d.prepare("select host_key, name, length(encrypted_value) n, hex(substr(encrypted_value,1,3)) p from cookies").all()));