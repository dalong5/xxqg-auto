import * as plain from './src/xxqg/plain.js';
const show = async () => (await plain.probe("(function(){var p=(document.body.innerText.match(/(\\d)\\/5/)||[])[0];var b=[].map.call(document.querySelectorAll('.q-answer'),function(e){return (e.className.indexOf('chosen')>=0?'*':'')+e.innerText.trim().slice(0,3)}).join('|');document.title='S '+p+' '+b})()")).replace(' - Google Chrome', '');
console.log('before', await show());
const out = await plain.advance();
console.log('decided', out.decided, 'hint', JSON.stringify((out.hint || '').slice(0, 40)));
await new Promise((x) => setTimeout(x, 1500));
console.log('after ', await show());