import * as plain from './src/xxqg/plain.js';
const geo = await plain.probe("(function(){document.title='G:'+JSON.stringify({sx:screenX,sy:screenY,ow:outerWidth,oh:outerHeight,iw:innerWidth,ih:innerHeight,d:devicePixelRatio})})()");
console.log('geo', geo.slice(0, 140));
const r = await plain.rects();
console.log('opt0', JSON.stringify(r.opts[0]));
const chk = `(function(){var d=devicePixelRatio;var oy=screenY*2+outerHeight*2-innerHeight*d;var ox=screenX*2+(outerWidth*2-innerWidth*d)/2;var X=${r.opts[0].c[0]},Y=${r.opts[0].c[1]};var cx=(X-ox)/d, cy=(Y-oy)/d;var e=document.elementFromPoint(cx,cy);document.title='E:'+JSON.stringify({cx:Math.round(cx),cy:Math.round(cy),hit:e?e.className+'/'+(e.innerText||'').slice(0,12):'null'})})()`;
console.log((await plain.probe(chk)).slice(0, 200));