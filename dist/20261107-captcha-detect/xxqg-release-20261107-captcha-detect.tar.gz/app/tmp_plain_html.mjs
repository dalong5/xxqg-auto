import * as plain from './src/xxqg/plain.js';
const JS = "(function(){var q=document.querySelector('.q-body');var p=q?q.parentElement:document.body;document.title=p.innerHTML.replace(/\\s+/g,' ').slice(0,420)})()";
console.log(await plain.probe(JS));