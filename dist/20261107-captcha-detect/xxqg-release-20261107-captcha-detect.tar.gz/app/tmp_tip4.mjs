import * as plain from './src/xxqg/plain.js';
const dump = async (tag) => {
  const t = await plain.probe("(function(){var p=document.querySelector('.ant-popover');var a=document.querySelector('.answer');document.title='D:'+JSON.stringify({pop:p?p.className+'|'+p.innerText.replace(/\\s+/g,' ').slice(0,50):'none',ans:a?a.innerText.slice(0,20):'none'})})()");
  console.log(tag, t.replace(' - Google Chrome', '').slice(0, 150));
};
await dump('before');
const r = await plain.rects();
console.log('tip', JSON.stringify(r.tip), 'opts', r.opts.length);
const tip = await plain.tipRect();
console.log('tipRect', JSON.stringify(tip));
if (tip) {
  await plain.clickAt(tip[0], tip[1]);
  await new Promise((x) => setTimeout(x, 2000));
  await dump('after1');
}