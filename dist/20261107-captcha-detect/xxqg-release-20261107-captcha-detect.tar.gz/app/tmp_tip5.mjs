import * as plain from './src/xxqg/plain.js';
const raw = await plain.probe(plain.TIP_JS);
console.log('raw=', JSON.stringify(raw).slice(0, 120));
const raw2 = await plain.probe("(function(){var e=document.querySelector('span.tips');document.title='X:'+(e?'yes':'no')})()");
console.log('span.tips=', raw2.slice(0, 60));
const raw3 = await plain.probe("(function(){var e=document.querySelector('.tips');document.title='Y:'+(e?e.className+'|'+e.getBoundingClientRect().width:'no')})()");
console.log('tips=', raw3.slice(0, 80));