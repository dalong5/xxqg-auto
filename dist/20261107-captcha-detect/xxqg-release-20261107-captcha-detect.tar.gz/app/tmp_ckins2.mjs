import fs from 'node:fs';
import crypto from 'node:crypto';
import { DatabaseSync } from 'node:sqlite';
const key = Buffer.from(fs.readFileSync('data/ck.key', 'utf8').trim(), 'base64');
const jar = JSON.parse(fs.readFileSync('data/ck.json', 'utf8'));
const db = new DatabaseSync('data/plain-profile/Default/Network/Cookies');
db.prepare('delete from cookies').run();
const now = BigInt(Date.now()) * 1000n + 11644473600000000n;
const exp = now + 86400n * 30n * 1000000n;
const ins = db.prepare(`INSERT INTO cookies (creation_utc, host_key, top_frame_site_key, name, value, encrypted_value, path, expires_utc, is_secure, is_httponly, last_access_utc, has_expires, is_persistent, priority, samesite, source_scheme, source_port, last_update_utc, source_type, has_cross_site_ancestor) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`);
for (const [name, value] of Object.entries(jar)) {
  const nonce = crypto.randomBytes(12);
  const c = crypto.createCipheriv('aes-256-gcm', key, nonce);
  const ct = Buffer.concat([c.update(value, 'utf8'), c.final()]);
  const blob = Buffer.concat([Buffer.from('v10'), nonce, ct, c.getAuthTag()]);
  ins.run(now, '.xuexi.cn', '', name, '', blob, '/', exp, 1, 1, now, 1, 1, 1, -1, 2, 443, now, 0, 0);
}
console.log('rows', JSON.stringify(db.prepare('select name, length(encrypted_value) n from cookies').all()));