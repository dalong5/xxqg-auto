import * as plain from './src/xxqg/plain.js';
const r = await plain.rects();
const fin = r.btns.find((b) => b.t.includes('确'));
console.log('fin', JSON.stringify(fin));
await plain.clickAt(fin.c[0], fin.c[1]);
await new Promise((x) => setTimeout(x, 1500));
console.log('txt', (await plain.probe("(function(){document.title='T:'+document.body.innerText.replace(/\\s+/g,' ').slice(0,150)})()")).slice(0, 160));