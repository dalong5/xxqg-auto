import { db } from './src/db.js';
console.log(JSON.stringify(db.prepare("select name from pragma_table_info('events')").all().map((r) => r.name)));
const j = db.prepare('select id,status,error from jobs order by created_at desc limit 1').get();
console.log('job', JSON.stringify(j));