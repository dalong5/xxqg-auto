import * as plain from './src/xxqg/plain.js';
const JS = "(function(){document.title=JSON.stringify({sx:screenX,sy:screenY,ox:outerWidth,oy:outerHeight,iw:innerWidth,ih:innerHeight,d:devicePixelRatio})})()";
console.log(await plain.probe(JS));