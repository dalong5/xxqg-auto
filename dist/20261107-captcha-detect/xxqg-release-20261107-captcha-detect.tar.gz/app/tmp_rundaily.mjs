import * as plain from './src/xxqg/plain.js';
import { Jar } from './src/xxqg/client.js';
import { DatabaseSync } from 'node:sqlite';
import { open as unseal } from './src/crypto.js';
const d = new DatabaseSync('data/app.db');
const jar = new Jar(unseal(d.prepare('select sealed_cookie from users where uid=?').get('151285666237.0').sealed_cookie));
process.env.XXQG_DEBUG = '1';
const out = await plain.runDaily('151285666237.0', jar);
console.log('RESULT', JSON.stringify(out));