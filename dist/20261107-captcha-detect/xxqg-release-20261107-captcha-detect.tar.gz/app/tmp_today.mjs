import { db } from './src/db.js';
const rows = db.prepare("select id,kind,status,error,created_at from jobs where created_at > ? order by created_at desc limit 6").all(Date.now() - 86400000);
for (const r of rows) console.log(new Date(Number(r.created_at)).toLocaleString('zh-CN'), r.kind, r.status, (r.error || '').slice(0, 40));