import { DatabaseSync } from 'node:sqlite';
const d = new DatabaseSync('data/app.db');
const jar = JSON.parse(d.prepare("select jar from logins where status='done' order by created_at desc limit 1").get().jar);
const ck = Object.entries(jar).map(([k, v]) => `${k}=${v}`).join('; ');
const H = { cookie: ck, 'content-type': 'application/json', origin: 'https://pc.xuexi.cn', referer: 'https://pc.xuexi.cn/points/exam-practice.html', 'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/156.0.0.0 Safari/537.36' };
for (const h of ['https://pc-proxy-api.xuexi.cn', 'https://pc-api.xuexi.cn', 'https://pc.xuexi.cn']) {
  const r = await fetch(h + '/api/exam/detectRisk', { method: 'POST', headers: H, body: JSON.stringify({ deviceToken: 'x' }) });
  console.log(h, r.status, (await r.text()).slice(0, 160).replace(/\n/g, ' '));
}