import * as plain from './src/xxqg/plain.js';
const pg = async () => (await plain.probe("(function(){var b=[].map.call(document.querySelectorAll('.q-answer'),function(e){return (e.className.indexOf('chosen')>=0?'*':'')+e.innerText.trim().slice(0,4)}).join('|');var p=(document.body.innerText.match(/(\\d)\\/5/)||[])[0];var t=(document.querySelector('.action-row button:last-child')||{}).innerText||'';document.title='S '+p+' btn='+t.trim()+' :: '+b})()")).replace(' - Google Chrome','');
for (let i = 0; i < 6; i++) {
  const st = await pg();
  console.log('at', st);
  if (/完/.test(st)) break;
  await plain.advance();
  await new Promise((x) => setTimeout(x, 1500));
}
console.log('final', await pg());