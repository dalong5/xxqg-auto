import * as plain from './src/xxqg/plain.js';
const pg = () => plain.probe("(function(){var b=[].map.call(document.querySelectorAll('.q-answer'),function(e){return (e.className.indexOf('chosen')>=0?'*':'')+e.innerText.trim().slice(0,6)}).join(' | ');var p=(document.body.innerText.match(/(\\d)\\/5/)||[])[0];document.title='S '+p+' :: '+b})()");
console.log('before', await pg());
await plain.advance();
await new Promise((x) => setTimeout(x, 1500));
console.log('after ', await pg());