import * as plain from './src/xxqg/plain.js';
const st = async (tag) => {
  const t = await plain.probe("(function(){var a=document.querySelectorAll('.q-answer');var b=[].map.call(a,function(e){return (e.className.indexOf('analysis')>=0?'X':'')+(e.className.indexOf('chosen')>=0?'*':'-')+e.innerText.trim().slice(0,3)}).join('|');var btn=document.querySelector('.action-row button:last-child');var p=(document.body.innerText.match(/(\\d)\\/5/)||[])[0];document.title='S '+p+' btn='+((btn||{}).innerText||'').trim()+' dis='+((btn||{}).disabled)+' '+b})()");
  console.log(tag, t.replace(' - Google Chrome', '').slice(0, 110));
};
await st('now  ');
const r = await plain.rects();
console.log('tip', JSON.stringify(r.tip), 'opts', r.opts.length, 'btn', JSON.stringify(r.btns[r.btns.length-1]));
const tip = await plain.tipRect();
console.log('tipRect', JSON.stringify(tip));
if (tip) {
  await plain.clickAt(tip[0], tip[1]);
  await new Promise((x) => setTimeout(x, 1500));
  await st('aftertip');
  console.log('hint', JSON.stringify((await plain.hintText()).slice(0, 50)));
}