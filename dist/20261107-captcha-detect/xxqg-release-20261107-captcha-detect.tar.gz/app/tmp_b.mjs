import * as plain from './src/xxqg/plain.js';
const JS = "(function(){document.title='B:'+document.body.innerText.replace(/\\s+/g,' ').slice(0,300)})()";
console.log((await plain.probe(JS)).slice(0, 320));