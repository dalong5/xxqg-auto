import * as plain from './src/xxqg/plain.js';
const a = await plain.probe("(function(){var e=document.querySelector('.q-footer-answer-tip-wrap .tips');document.title='Q1:'+(e?'yes':'no')})()");
console.log('q1', a.slice(0, 40));
const b = await plain.probe("(function(){var e=document.querySelector('.q-footer-answer-tip-wrap .tips');e.scrollIntoView({block:'center'});document.title='Q2:ok'})()");
console.log('q2', b.slice(0, 40));
const c = await plain.probe("(function(){var e=document.querySelector('.q-footer-answer-tip-wrap .tips');var d=devicePixelRatio;var oy=screenY*2+outerHeight*2-innerHeight*d;var ox=screenX*2+(outerWidth*2-innerWidth*d)/2;e.scrollIntoView({block:'center'});var r=e.getBoundingClientRect();document.title='Q3:'+JSON.stringify([Math.round(ox+(r.x+r.width/2)*d),Math.round(oy+(r.y+r.height/2)*d)])})()");
console.log('q3', c.slice(0, 60));