import * as plain from './src/xxqg/plain.js';
const r = await plain.rects();
console.log('rects', JSON.stringify(r).slice(0, 200));
const chk = `(function(){var d=devicePixelRatio;var s=${JSON.stringify(r)};var out=[];var f=function(p){var e=document.elementFromPoint(p[0],p[1]);return e?e.tagName+':'+(e.innerText||'').slice(0,12):'null'};if(s.opts)for(var i=0;i<s.opts.length;i++)out.push(f(s.opts[i].c));document.title='CHK '+JSON.stringify(out)})()`;
console.log(await plain.probe(chk));