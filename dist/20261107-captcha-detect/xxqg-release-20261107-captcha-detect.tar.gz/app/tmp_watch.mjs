﻿import { db } from './src/db.js';
const jobId = db.prepare("select id from jobs where status in ('running','pausing','paused') order by rowid desc limit 1").get()?.id;
if (!jobId) { console.log('没有进行中的任务'); process.exit(0); }
let lastSeq = db.prepare('select max(seq) m from events where job_id = ?').get(jobId).m || 0;
const t0 = Date.now();
while (Date.now() - t0 < 200_000) {
  const rows = db.prepare('select seq, type, payload, created_at from events where job_id = ? and seq > ? order by seq').all(jobId, lastSeq);
  for (const e of rows) {
    lastSeq = e.seq;
    const p = String(e.payload || '').replace(/\s+/g, ' ');
    const short = e.type === 'verification' ? '[截图帧] ' + p.slice(0, 40) : p.slice(0, 120);
    console.log(new Date(Number(e.created_at)).toLocaleTimeString('zh-CN'), e.type.padEnd(12), short);
  }
  const j = db.prepare('select status, error from jobs where id = ?').get(jobId);
  if (j && !['running','pausing','paused'].includes(j.status)) { console.log('任务结束:', j.status, j.error || ''); break; }
  await new Promise(r => setTimeout(r, 3000));
}
const j = db.prepare('select status, error from jobs where id = ?').get(jobId);
console.log('当前状态:', j.status, j.error || '');
