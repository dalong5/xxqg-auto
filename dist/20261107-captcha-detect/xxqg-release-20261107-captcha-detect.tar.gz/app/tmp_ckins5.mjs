import fs from 'node:fs';
import crypto from 'node:crypto';
import { DatabaseSync } from 'node:sqlite';
const key = Buffer.from(fs.readFileSync('data/ck.key', 'utf8').trim(), 'base64');
const jar = JSON.parse(fs.readFileSync('data/ck.json', 'utf8'));
const db = new DatabaseSync('data/plain-profile/Default/Network/Cookies');
const host = '.xuexi.cn';
const h = crypto.createHash('sha256').update(host).digest();
const now = Math.round((Date.now() + 11644473600000) * 1000);
const exp = now + 86400 * 30 * 1000000;
const ins = db.prepare(`INSERT INTO cookies (creation_utc, host_key, top_frame_site_key, name, value, encrypted_value, path, expires_utc, is_secure, is_httponly, last_access_utc, has_expires, is_persistent, priority, samesite, source_scheme, source_port, last_update_utc, source_type, has_cross_site_ancestor) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`);
for (const [name, value] of Object.entries(jar)) {
  db.prepare('DELETE FROM cookies WHERE name = ? AND host_key = ?').run(name, host);
  const nonce = crypto.randomBytes(12);
  const c = crypto.createCipheriv('aes-256-gcm', key, nonce);
  const ct = Buffer.concat([c.update(Buffer.concat([h, Buffer.from(value, 'utf8')])), c.final()]);
  ins.run(now, host, '', name, '', Buffer.concat([Buffer.from('v10'), nonce, ct, c.getAuthTag()]), '/', exp, 1, 0, now, 1, 1, 1, -1, 2, 443, now, 0, 0);
}
console.log('reinserted as non-httponly');