const fs = require('fs');
const p = 'scripts/native.ps1';
let s = fs.readFileSync(p, 'utf8');
const a = s.indexOf('function Get-Win {');
const b = s.indexOf('function Send-Key(');
if (a < 0 || b < 0) throw new Error('markers not found');
const repl = [
  'function Get-Win {',
  '  for ($i = 0; $i -lt 20; $i++) {',
  '    $list = @(Get-Process chrome -ErrorAction SilentlyContinue | Where-Object { $_.MainWindowHandle -ne 0 })',
  '    if ($list.Count -gt 0) {',
  '      $hit = $list | Where-Object { $_.MainWindowTitle -match "xuexi|Chrome" } | Select-Object -First 1',
  '      if (-not $hit) { $hit = $list[0] }',
  '      return $hit',
  '    }',
  '    Start-Sleep -Milliseconds 800',
  '  }',
  "  throw 'no chrome window'",
  '}',
  'function Focus-Win($h) {',
  "  if (-not $h -or $h -eq [IntPtr]::Zero) { throw 'window handle gone' }",
  '  [N]::ShowWindow($h, 9) | Out-Null',
  '  [N]::SetForegroundWindow($h) | Out-Null',
  '  Start-Sleep -Milliseconds 250',
  '}',
  '',
].join('\r\n');
s = s.slice(0, a) + repl + s.slice(b);
fs.writeFileSync(p, s);
console.log('patched');