import { userInfo } from './src/xxqg/client.js';
import { DatabaseSync } from 'node:sqlite';
import { open } from './src/crypto.js';
import { Jar } from './src/xxqg/client.js';
const d = new DatabaseSync('data/app.db');
const jar = new Jar(open(d.prepare('select sealed_cookie from users where uid=?').get('151285666237.0').sealed_cookie));
try {
  const u = await userInfo(jar);
  console.log('token valid:', JSON.stringify(u).slice(0, 120));
} catch (e) {
  console.log('token invalid:', e.message.slice(0, 80));
}
process.exit(0);