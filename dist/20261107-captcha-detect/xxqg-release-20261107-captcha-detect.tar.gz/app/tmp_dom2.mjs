import * as plain from './src/xxqg/plain.js';
const JS = "(function(){var q=document.querySelector('.q-body');var h=q.parentElement.innerHTML.replace(/\\s+/g,' ');document.title='T:'+h.slice(430,900)})()";
console.log(await plain.probe(JS));