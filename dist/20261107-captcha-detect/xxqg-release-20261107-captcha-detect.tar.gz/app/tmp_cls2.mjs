import * as plain from './src/xxqg/plain.js';
const dump = async (tag) => {
  const t = await plain.probe("(function(){var a=[].map.call(document.querySelectorAll('.q-answer'),function(e){return e.className});document.title='C:'+a.join(' | ').slice(0,150)})()");
  console.log(tag, t.replace(' - Google Chrome', '').slice(0, 160));
};
const r = await plain.rects();
await dump('before');
await plain.clickAt(r.opts[0].c[0], r.opts[0].c[1]);
await new Promise((x) => setTimeout(x, 1200));
await dump('after ');