import { DatabaseSync } from 'node:sqlite';
const d = new DatabaseSync('data/app.db');
const j = d.prepare('select id, status from jobs order by created_at desc limit 1').get();
console.log(JSON.stringify(j));
for (const e of d.prepare("select type, payload from events where job_id = ? order by seq desc limit 6").all(j.id)) {
  console.log(e.type, '|', (e.payload || '').slice(0, 90));
}