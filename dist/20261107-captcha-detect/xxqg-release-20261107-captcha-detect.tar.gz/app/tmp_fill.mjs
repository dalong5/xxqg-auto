import * as plain from './src/xxqg/plain.js';
const JS = "(function(){var b=[].map.call(document.querySelectorAll('.click-box'),function(e){return e.innerText.trim()}).join(',');var p=(document.body.innerText.match(/(\\d)\\/5/)||[])[0];document.title='S:'+p+'|'+b})()";
console.log(await plain.probe(JS));