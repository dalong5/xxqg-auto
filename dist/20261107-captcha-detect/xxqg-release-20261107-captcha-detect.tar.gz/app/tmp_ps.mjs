import { execFile } from 'node:child_process';
function ps(args) {
  return new Promise((res, rej) => {
    execFile('powershell.exe', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', 'scripts/native.ps1', ...args], { cwd: process.cwd() }, (e, out, err) => {
      if (e) rej(new Error((err || e.message).trim()));
      else res(out.trim());
    });
  });
}
console.log('list:', await ps(['-Action', 'list']));