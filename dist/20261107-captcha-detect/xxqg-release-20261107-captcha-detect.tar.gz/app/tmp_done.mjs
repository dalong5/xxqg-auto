import * as plain from './src/xxqg/plain.js';
const r = await plain.rects();
const fin = (r.btns || []).find((b) => /完/.test(b.t));
console.log('fin', JSON.stringify(fin));
await plain.clickAt(fin.c[0], fin.c[1]);
await new Promise((x) => setTimeout(x, 2500));
const s = await plain.rects();
console.log('slider', JSON.stringify(s.slider), 'track', JSON.stringify(s.track));
console.log('txt', (await plain.probe("(function(){document.title='T:'+document.body.innerText.replace(/\\s+/g,' ').slice(0,120)})()")).slice(0, 130));