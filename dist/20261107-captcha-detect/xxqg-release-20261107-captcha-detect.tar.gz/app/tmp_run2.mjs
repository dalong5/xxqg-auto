import * as plain from './src/xxqg/plain.js';
const pg = async () => (await plain.probe("(function(){var p=(document.body.innerText.match(/(\\d)\\/5/)||[])[0];var t=(document.querySelector('.action-row button:last-child')||{}).innerText||'';var q=(document.querySelector('.q-body')||{innerText:''}).innerText.slice(0,10);document.title='S '+p+' btn='+t.trim()+' q='+q})()")).replace(' - Google Chrome','');
for (let i = 0; i < 8; i++) {
  const st = await pg();
  console.log('at', st);
  if (/完/.test(st)) break;
  const out = await plain.advance();
  console.log('  ->', out.decided, (out.hint || '').slice(0, 30));
  await new Promise((x) => setTimeout(x, 900));
}
console.log('final', await pg());