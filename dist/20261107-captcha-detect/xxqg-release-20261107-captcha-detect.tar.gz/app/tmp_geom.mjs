import fs from 'node:fs';
let s = fs.readFileSync('src/server.js', 'utf8');
const anchor = `// 没有账号也能跑的自检任务`;
const add = `// 调试桥：无 CDP 的普通 Chrome 由插件把页面几何报回来（仅本机用）
app.options('/api/dev/geom', (req, res) => {
  res.setHeader('access-control-allow-origin', '*');
  res.setHeader('access-control-allow-headers', 'content-type');
  res.end();
});
app.post('/api/dev/geom', (req, res) => {
  res.setHeader('access-control-allow-origin', '*');
  fs.writeFileSync(path.join(config.dataDir, 'geom.json'), JSON.stringify(req.body || {}));
  res.json({ ok: true });
});

// 没有账号也能跑的自检任务`;
if (!s.includes('/api/dev/geom')) s = s.replace(anchor, add);
if (!s.includes("import fs from 'node:fs'")) s = s.replace("import path from 'node:path';", "import path from 'node:path';\nimport fs from 'node:fs';");
fs.writeFileSync('src/server.js', s);
console.log('geom endpoint added, fs imported:', s.includes("import fs from 'node:fs'"));