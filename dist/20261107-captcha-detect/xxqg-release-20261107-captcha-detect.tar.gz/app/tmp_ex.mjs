import * as plain from './src/xxqg/plain.js';
console.log('exports', Object.keys(plain).join(','));