import { chromium } from 'playwright';
import { DatabaseSync } from 'node:sqlite';
const d = new DatabaseSync('data/app.db');
const jar = JSON.parse(d.prepare("select jar from logins where status='done' order by created_at desc limit 1").get().jar);
const cookies = Object.entries(jar).map(([name, value]) => ({ name, value, domain: '.xuexi.cn', path: '/' }));
const b = await chromium.launch({ channel: 'chrome', headless: true });
const ctx = await b.newContext({ locale: 'zh-CN', viewport: { width: 1440, height: 900 } });
await ctx.addInitScript(() => {
  window.__fp = [];
  const orig = JSON.stringify;
  JSON.stringify = function (v) {
    const s = orig.apply(this, arguments);
    try { if (typeof s === 'string' && s.includes('dghfh565')) window.__fp.push(s); } catch (e) {}
    return s;
  };
});
await ctx.addCookies(cookies);
const p = await ctx.newPage();
await p.goto('https://pc.xuexi.cn/points/my-points.html', { waitUntil: 'domcontentloaded' });
await p.waitForTimeout(3000);
await p.locator('.my-points-card', { hasText: '每日答题' }).first().locator('text=去答题').first().click();
await p.waitForTimeout(6000);
const arr = await p.evaluate(() => window.__fp);
console.log('objs', arr.length);
const o = JSON.parse(arr[arr.length - 1]);
for (const [k, v] of Object.entries(o)) console.log(k, '=', JSON.stringify(v).slice(0, 120));
await b.close();