import * as plain from './src/xxqg/plain.js';
const r = await plain.rects();
console.log('opts', (r.opts||[]).length, 'btns', (r.btns||[]).map(b=>b.t).join(','), 'q', (r.q||'').slice(0,20));
console.log('probe2', (await plain.probe("document.title='K:'+document.querySelectorAll('.q-answer').length")).slice(0,40));
console.log('probe3', (await plain.probe("document.title='K2:'+document.querySelectorAll('.q-answer').length")).slice(0,40));