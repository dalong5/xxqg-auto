import { db } from './src/db.js';
const uid = '151285666237.0';
const at = '07:30';
const next = new Date();
next.setHours(7, 30, 0, 0);
if (next.getTime() < Date.now()) next.setDate(next.getDate() + 1);
db.prepare('update users set schedule=?, next_run_at=? where uid=?').run(at, next.getTime(), uid);
console.log('schedule', at, new Date(next.getTime()).toLocaleString('zh-CN'));
console.log(JSON.stringify(db.prepare('select uid,schedule,next_run_at from users').all()));