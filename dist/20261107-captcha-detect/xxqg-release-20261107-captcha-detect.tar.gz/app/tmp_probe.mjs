import * as plain from './src/xxqg/plain.js';
const r = await plain.rects();
console.log('raw?', !!r.raw);
console.log('q', (r.q || '').slice(0, 30));
console.log('opts', (r.opts || []).length, 'blanks', (r.blanks || []).length, 'tiles', (r.tiles || []).map((t) => t.t).join('/'), 'inputs', (r.inputs || []).length, 'btns', (r.btns || []).map((b) => b.t).join(','));
console.log('title', (await plain.title()).slice(0, 60));