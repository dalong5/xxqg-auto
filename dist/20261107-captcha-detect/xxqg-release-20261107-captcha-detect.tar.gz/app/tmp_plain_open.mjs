import * as plain from './src/xxqg/plain.js';
console.log(await plain.open('151285666237.0', 'https://pc.xuexi.cn/points/exam-practice.html'));