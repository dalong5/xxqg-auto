import * as plain from './src/xxqg/plain.js';
const JS = "(function(){var t=document.body.innerText.replace(/\\s+/g,' ');document.title=t.slice(100,320)})()";
console.log(await plain.probe(JS));