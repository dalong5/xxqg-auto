import * as plain from './src/xxqg/plain.js';
const JS = "(function(){var n=0;var t=setInterval(function(){var a=document.querySelectorAll('.q-answer.choosable');if(a.length){a[0].click()}else{var tk=document.querySelectorAll('[class*=blank] span,[class*=word] span,.q-fill span');for(var i=0;i<tk.length&&i<3;i++){if(tk[i].innerText.trim())tk[i].click()}}var bs=document.querySelectorAll('.action-row button');for(var k=0;k<bs.length;k++){if(bs[k].innerText.indexOf('确')>=0){bs[k].click();break}}if(++n>6)clearInterval(t)},1700)})()";
console.log(await plain.probe(JS));
await new Promise((r) => setTimeout(r, 12000));
console.log('after', JSON.stringify(await plain.state()).slice(0, 200));
console.log('title', await plain.title());