import * as plain from './src/xxqg/plain.js';
const pg = async () => (await plain.probe("(function(){var b=[].map.call(document.querySelectorAll('.q-answer'),function(e){return (e.className.indexOf('chosen')>=0?'*':'')+e.innerText.trim().slice(0,3)}).join('|');var p=(document.body.innerText.match(/(\\d)\\/5/)||[])[0];var t=(document.querySelector('.action-row button:last-child')||{}).innerText||'';document.title='S '+p+' btn='+t.trim()+' :: '+b})()")).replace(' - Google Chrome','');
for (let i = 0; i < 5; i++) {
  const st = await pg();
  console.log('at', st);
  if (/完/.test(st)) break;
  const out = await plain.advance();
  console.log('  ->', out.decided, JSON.stringify(out.hint || '').slice(0, 80));
  await new Promise((x) => setTimeout(x, 1200));
}
console.log('final', await pg());