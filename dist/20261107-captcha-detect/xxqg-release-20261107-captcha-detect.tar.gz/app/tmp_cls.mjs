import * as plain from './src/xxqg/plain.js';
const JS = "(function(){var a=[].filter.call(document.querySelectorAll('div,span'),function(e){return /word|blank|tile|option|choice|click/.test(String(e.className))});document.title='W:'+a.map(function(e){return e.className+'='+(e.innerText||'').replace(/\\s+/g,'').slice(0,8)}).join(' | ').slice(0,420)})()";
console.log(await plain.probe(JS));