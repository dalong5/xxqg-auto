import * as plain from './src/xxqg/plain.js';
const JS = "(function(){var n=0;var t=setInterval(function(){var inp=document.querySelectorAll('input.blank');if(inp.length){for(var i=0;i<inp.length;i++){inp[i].value='test';inp[i].dispatchEvent(new Event('input',{bubbles:true}))}}var a=document.querySelectorAll('.q-answer.choosable');if(a.length){a[0].click()}var bs=document.querySelectorAll('.action-row button');for(var k=0;k<bs.length;k++){if(bs[k].innerText.indexOf('确')>=0){bs[k].click();break}}if(++n>6)clearInterval(t)},1700)})()";
await plain.probe(JS);
await new Promise((r) => setTimeout(r, 13000));
console.log('after', JSON.stringify(await plain.state()).slice(0, 160));