import fs from 'node:fs';
import { db } from './src/db.js';

const job = db.prepare("select id from jobs where status = 'running' order by rowid desc limit 1").get();
if (!job) {
  console.log('no running job');
  process.exit(0);
}
const v = db.prepare("select payload, created_at from events where job_id = ? and type = 'verification' order by seq desc limit 1").get(job.id);
if (!v) {
  console.log('no verification frame (已通过?)');
  process.exit(0);
}
const obj = JSON.parse(v.payload);
fs.writeFileSync('../logs/captcha-now.jpg', Buffer.from(String(obj.image || obj), 'base64'));
console.log('saved', obj.width + 'x' + obj.height, new Date(Number(v.created_at)).toLocaleTimeString('zh-CN'));
