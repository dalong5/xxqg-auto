import { db } from './src/db.js';
const cols = (t) => db.prepare(`select name from pragma_table_info('${t}')`).all().map((r) => r.name);
console.log('logins cols', cols('logins').join(','));
const rows = db.prepare('select * from logins order by rowid desc limit 5').all();
for (const r of rows) console.log(JSON.stringify({ sid: r.sid, status: r.status, uid: r.uid, err: r.error, visitor: r.visitor_id, at: new Date(Number(r.created_at || 0)).toLocaleString('zh-CN') }));
const u = db.prepare('select uid, nick, visitor_id, last_run_at from users').all();
console.log('users', JSON.stringify(u.map((x) => ({ ...x, last_run_at: x.last_run_at ? new Date(Number(x.last_run_at)).toLocaleString('zh-CN') : null }))));