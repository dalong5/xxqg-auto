import { db } from './src/db.js';

const job = db.prepare("select id from jobs where status = 'running' order by rowid desc limit 1").get();
if (!job) { console.log('no job'); process.exit(0); }
const frame = db.prepare("select type, payload from events where job_id = ? order by seq desc limit 1").get(job.id);
if (frame?.type !== 'verification') { console.log('no pending verification:', frame?.type); process.exit(0); }
const { width, height } = JSON.parse(frame.payload);

const startX = Math.round(width * 0.395); // 手柄中心 ≈590
const y = Math.round(height * 0.5645);     // ≈508
const endX = Math.round(width * 0.6225);   // ≈930，贴到轨道右缘
console.log('drag', startX, y, '->', endX, y, 'viewport', width + 'x' + height);

const ins = db.prepare('INSERT INTO verification_actions (job_id, kind, x, y) VALUES (?,?,?,?)');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
db.prepare('DELETE FROM verification_actions WHERE job_id = ?').run(job.id);

ins.run(job.id, 'move', startX, y);
await sleep(90);
ins.run(job.id, 'down', startX, y);
await sleep(160);

const steps = 18;
for (let i = 1; i <= steps; i++) {
  const t = i / steps;
  const eased = 1 - Math.pow(1 - t, 2.2);
  ins.run(job.id, 'move', Math.round(startX + (endX - startX) * eased), y);
  await sleep(55 + Math.random() * 45);
}
ins.run(job.id, 'move', endX, y);
await sleep(180);
ins.run(job.id, 'up', endX, y);
console.log('sent; waiting 3s');
await sleep(3000);
const last = db.prepare('select type from events where job_id = ? order by seq desc limit 1').get(job.id);
const j = db.prepare('select status, error from jobs where id = ?').get(job.id);
console.log('last event:', last?.type, '| job:', j.status, j.error || '');
