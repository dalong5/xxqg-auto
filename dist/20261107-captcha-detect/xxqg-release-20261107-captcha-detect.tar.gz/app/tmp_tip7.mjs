import * as plain from './src/xxqg/plain.js';
const t1 = await plain.probe("(function(){document.title='Z1:'+(document.body.innerText.indexOf('查看提示')>=0)})()");
console.log('t1', t1.slice(0, 40));
const t2 = await plain.probe("(function(){var all=[].slice.call(document.querySelectorAll('span,div'));var n=0;for(var i=0;i<all.length;i++){if(all[i].children.length===0&&(all[i].innerText||'').trim()==='查看提示')n++}document.title='Z2:'+n})()");
console.log('t2', t2.slice(0, 40));
const t3 = await plain.probe(plain.TIP_JS);
console.log('t3', t3.slice(0, 60));