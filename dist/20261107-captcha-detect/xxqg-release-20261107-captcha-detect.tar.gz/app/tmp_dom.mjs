import * as plain from './src/xxqg/plain.js';
const JS = "(function(){var q=document.querySelector('.q-body');document.title='H:'+(q?q.innerHTML.replace(/\\s+/g,' ').slice(0,460):'NOQBODY')})()";
console.log(await plain.probe(JS));