import * as plain from './src/xxqg/plain.js';
const r = await plain.rects();
const b = r.blanks[0];
await plain.clickAt(b[0], b[1]);
await new Promise((x) => setTimeout(x, 900));
console.log(await plain.probe("(function(){var e=document.querySelectorAll('.click-box')[0];document.title='X:'+e.className+'|'+e.innerText})()"));