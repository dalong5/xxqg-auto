import * as plain from './src/xxqg/plain.js';
import { Jar, score } from './src/xxqg/client.js';
import { DatabaseSync } from 'node:sqlite';
import { open as unseal } from './src/crypto.js';
const uid = '151285958047.0';
const d = new DatabaseSync('data/app.db');
const jar = new Jar(unseal(d.prepare('select sealed_cookie from users where uid=?').get(uid).sealed_cookie));
const log = (...a) => console.log(new Date().toISOString().slice(11, 19), ...a);

await plain.seedProfile(uid, jar);
await plain.open(uid, 'https://pc.xuexi.cn/points/exam-practice.html');
log('opened');

for (let q = 1; q <= 8; q++) {
  const r = await plain.rects();
  const btns = (r.btns || []).map((b) => b.t.replace(/\s/g, ''));
  log(`q${q} ready=${r.ready} opts=${(r.opts || []).length} blanks=${(r.blanks || []).length} btns=${btns.join('/')}`);
  if (btns.some((b) => b.includes('完成'))) break;

  // 1) 看提示拿答案
  let hint = '';
  const tip = await plain.tipRect();
  if (tip) {
    await plain.clickAt(tip[0], tip[1]);
    for (let i = 0; i < 5 && !hint; i++) {
      await new Promise((x) => setTimeout(x, 500));
      hint = await plain.hintText();
    }
  }
  log('  hint=' + JSON.stringify(hint.slice(0, 40)));

  // 2) 按答案点
  const r2 = await plain.rects();
  if (r2.opts?.length) {
    const letters = (hint.match(/正确答案[:：]\s*([A-N][A-N\s、,，]*)/) || [])[1] || '';
    const idx = [...letters.replace(/[^A-N]/g, '')].map((c) => c.charCodeAt(0) - 65);
    const use = idx.length ? idx : [0];
    for (const i of use) if (r2.opts[i]) { await plain.clickAt(r2.opts[i].c[0], r2.opts[i].c[1]); await new Promise((x) => setTimeout(x, 300)); }
    log('  click opts ' + use.join(','));
  } else if (r2.blanks?.length) {
    const parts = hint.split('|').map((s) => s.trim()).filter(Boolean);
    const chars = parts.length ? parts.join('') : hint.replace(/正确答案[:：]/, '');
    let i = 0;
    for (const b of r2.blanks) {
      await plain.clickAt(b[0], b[1]);
      await new Promise((x) => setTimeout(x, 250));
      const ch = chars[i++];
      const t = (r2.tiles || []).find((t2) => t2.t && ch && t2.t.includes(ch));
      if (t) { await plain.clickAt(t.c[0], t.c[1]); await new Promise((x) => setTimeout(x, 300)); }
    }
    log('  fill blanks');
  }
  // 3) 确定/下一题
  const r3 = await plain.rects();
  const btn = (r3.btns || []).slice(-1)[0];
  if (btn) { await plain.clickAt(btn.c[0], btn.c[1]); log('  click ' + btn.t.replace(/\s/g, '') + ' dis=' + btn.d); }
  await new Promise((x) => setTimeout(x, 2500));
}

// 交卷
const r = await plain.rects();
const fin = (r.btns || []).find((b) => /完成/.test(b.t));
log('final btns=' + (r.btns || []).map((b) => b.t).join('/'));
if (fin) {
  await plain.clickAt(fin.c[0], fin.c[1]);
  await new Promise((x) => setTimeout(x, 2500));
  const s = await plain.rects();
  log('slider=' + JSON.stringify(s.slider) + ' track=' + JSON.stringify(s.track));
  if (s.slider && s.track) {
    await plain.drag(s.slider[0], s.slider[1], s.track[0], s.track[1], 34);
    await new Promise((x) => setTimeout(x, 4000));
  }
}
const after = await score(jar);
log('RESULT 每日答题=' + JSON.stringify(after.tasks?.[6]) + ' 总分=' + after.total);