import * as plain from './src/xxqg/plain.js';
console.log('state', JSON.stringify(await plain.state()).slice(0, 220));