import * as plain from './src/xxqg/plain.js';
const t = await plain.probe("(function(){var a=[].filter.call(document.querySelectorAll('div'),function(e){return e.innerText&&e.innerText.indexOf('正确答案')>=0&&e.innerText.length<400});var e=a[a.length-1];document.title='SEL:'+(e?e.className+'|'+e.innerText.replace(/\\s+/g,' ').slice(0,80):'none')})()");
console.log(t.slice(0, 200));