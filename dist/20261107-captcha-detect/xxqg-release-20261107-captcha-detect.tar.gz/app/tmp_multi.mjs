import * as plain from './src/xxqg/plain.js';
const show = async (tag) => {
  const t = await plain.probe("(function(){var b=[].map.call(document.querySelectorAll('.q-answer'),function(e){return (e.className.indexOf('chosen')>=0?'*':'')+e.innerText.trim().slice(0,3)}).join('|');var p=(document.body.innerText.match(/(\\d)\\/5/)||[])[0];var btn=(document.querySelector('.action-row button:last-child')||{}).innerText||'';document.title='S '+p+' ['+btn.trim()+'] '+b})()");
  console.log(tag, t.replace(' - Google Chrome', '').slice(0, 70));
};
const r = await plain.rects();
await show('start');
for (const o of r.opts) {
  await plain.clickAt(o.c[0], o.c[1]);
  await new Promise((x) => setTimeout(x, 400));
}
await show('picked');
const r2 = await plain.rects();
const btn = r2.btns[r2.btns.length - 1];
console.log('btn', JSON.stringify(btn));
await plain.clickAt(btn.c[0], btn.c[1]);
await new Promise((x) => setTimeout(x, 1800));
await show('after');