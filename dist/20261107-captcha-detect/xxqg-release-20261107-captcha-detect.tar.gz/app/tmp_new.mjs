import { Jar, score, userInfo } from './src/xxqg/client.js';
import { DatabaseSync } from 'node:sqlite';
import { open as unseal } from './src/crypto.js';
const d = new DatabaseSync('data/app.db');
const jar = new Jar(unseal(d.prepare('select sealed_cookie from users where uid=?').get('151285958047.0').sealed_cookie));
console.log('info', JSON.stringify(await userInfo(jar).catch((e) => ({ err: e.message }))).slice(0, 160));
console.log('score', JSON.stringify(await score(jar)).slice(0, 220));