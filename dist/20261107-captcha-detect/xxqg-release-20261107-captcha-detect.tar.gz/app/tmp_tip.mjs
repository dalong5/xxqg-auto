import * as plain from './src/xxqg/plain.js';
const r = await plain.rects();
console.log('tip', JSON.stringify(r.tip), 'btns', (r.btns||[]).map(b=>b.t).join(','));
await plain.clickAt(r.tip[0], r.tip[1]);
await new Promise((x) => setTimeout(x, 900));
console.log('pop', (await plain.probe("(function(){var a=[].map.call(document.querySelectorAll('[class*=popover],[class*=tip]'),function(e){return e.className+':'+(e.innerText||'').replace(/\\s+/g,' ').slice(0,40)});document.title='P:'+a.join(' || ').slice(0,380)})()")).slice(0, 300));